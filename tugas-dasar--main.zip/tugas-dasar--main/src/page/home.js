import React from 'react'

export default class Home extends React.Component {
    render() {
        return (
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://drive.google.com/uc?id=1RLUOj3D1s7q6FRuWaXZXZQcKE3YVgjpx" class="d-block w-100" alt="1" />
                    </div>
                </div>
            </div>
        )
    }
}